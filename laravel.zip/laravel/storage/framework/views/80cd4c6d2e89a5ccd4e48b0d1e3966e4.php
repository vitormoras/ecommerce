

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-md-6">
            <h2><i class="fas fa-tags me-2"></i>Categorias</h2>
        </div>
        <div class="col-md-6 text-end">
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Nova Categoria
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Imagem</th>
                            <th>Nome</th>
                            <th>Descrição</th>
                            <th>Produtos</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php if($category->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $category->image)); ?>" 
                                             alt="<?php echo e($category->name); ?>"
                                             class="category-thumbnail">
                                    <?php else: ?>
                                        <div class="category-placeholder">
                                            <i class="fas fa-folder"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e(Str::limit($category->description, 100)); ?></td>
                                <td><?php echo e($category->products->count()); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('categories.show', $category)); ?>" 
                                           class="btn btn-sm btn-info"
                                           title="Ver produtos">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('categories.edit', $category)); ?>" 
                                           class="btn btn-sm btn-primary"
                                           title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('categories.destroy', $category)); ?>" 
                                              method="POST" 
                                              class="d-inline"
                                              onsubmit="return confirm('Tem certeza que deseja excluir esta categoria?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i>
                                        Nenhuma categoria cadastrada.
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    .category-thumbnail {
        width: 50px;
        height: 50px;
        object-fit: cover;
        border-radius: 4px;
    }

    .category-placeholder {
        width: 50px;
        height: 50px;
        background-color: #f8f9fa;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
    }

    .btn-group {
        display: flex;
        gap: 0.25rem;
    }

    .btn-group .btn {
        padding: 0.25rem 0.5rem;
    }
</style>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\laravel\resources\views/categories/index.blade.php ENDPATH**/ ?>