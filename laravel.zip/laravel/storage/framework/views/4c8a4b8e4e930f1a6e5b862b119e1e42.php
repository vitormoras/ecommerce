<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <h2><i class="fas fa-store me-2"></i>Vitrine de Produtos</h2>
    </div>

    <!-- Seção de Categorias -->
    <div class="categories-section mb-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title mb-3">
                    <i class="fas fa-tags me-2"></i>Categorias
                </h5>
                <div class="row g-2">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-auto">
                            <a href="<?php echo e(route('categories.show', $category)); ?>" 
                               class="btn btn-outline-primary btn-sm">
                                <?php if($category->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $category->image)); ?>" 
                                         alt="<?php echo e($category->name); ?>"
                                         class="category-icon me-1">
                                <?php else: ?>
                                    <i class="fas fa-folder me-1"></i>
                                <?php endif; ?>
                                <?php echo e($category->name); ?>

                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Seção de Filtros -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('products.vitrine')); ?>" method="GET" class="row g-3">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text" 
                               class="form-control" 
                               name="search" 
                               placeholder="Buscar produtos..."
                               value="<?php echo e(request('search')); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="order">
                        <option value="">Ordenar por...</option>
                        <option value="price_asc" <?php echo e(request('order') == 'price_asc' ? 'selected' : ''); ?>>
                            Menor Preço
                        </option>
                        <option value="price_desc" <?php echo e(request('order') == 'price_desc' ? 'selected' : ''); ?>>
                            Maior Preço
                        </option>
                        <option value="name_asc" <?php echo e(request('order') == 'name_asc' ? 'selected' : ''); ?>>
                            Nome (A-Z)
                        </option>
                        <option value="name_desc" <?php echo e(request('order') == 'name_desc' ? 'selected' : ''); ?>>
                            Nome (Z-A)
                        </option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="availability">
                        <option value="">Disponibilidade</option>
                        <option value="in_stock" <?php echo e(request('availability') == 'in_stock' ? 'selected' : ''); ?>>
                            Em Estoque
                        </option>
                        <option value="out_of_stock" <?php echo e(request('availability') == 'out_of_stock' ? 'selected' : ''); ?>>
                            Fora de Estoque
                        </option>
                    </select>
                </div>
                <div class="col-md-2">
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter me-2"></i>Filtrar
                        </button>
                    </div>
                </div>
                <?php if(request()->anyFilled(['search', 'order', 'availability'])): ?>
                    <div class="col-12">
                        <a href="<?php echo e(route('products.vitrine')); ?>" class="btn btn-link text-decoration-none">
                            <i class="fas fa-times me-2"></i>Limpar Filtros
                        </a>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Lista de Produtos -->
    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-md-6 col-lg-4 col-xl-3">
                <div class="card product-card h-100">
                    <?php if($product->stock <= 5 && $product->stock > 0): ?>
                        <div class="stock-badge">
                            <span class="badge bg-warning text-dark">
                                <i class="fas fa-exclamation-triangle me-1"></i>
                                Últimas Unidades
                            </span>
                        </div>
                    <?php elseif($product->stock == 0): ?>
                        <div class="stock-badge">
                            <span class="badge bg-danger">
                                <i class="fas fa-times-circle me-1"></i>
                                Fora de Estoque
                            </span>
                        </div>
                    <?php endif; ?>

                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" 
                             class="product-image" 
                             alt="<?php echo e($product->name); ?>">
                    <?php else: ?>
                        <div class="text-center p-4 bg-light">
                            <i class="fas fa-image fa-4x text-muted"></i>
                        </div>
                    <?php endif; ?>

                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                        <?php if($product->category): ?>
                            <div class="mb-2">
                                <a href="<?php echo e(route('categories.show', $product->category)); ?>" 
                                   class="badge bg-info text-decoration-none">
                                    <i class="fas fa-tag me-1"></i>
                                    <?php echo e($product->category->name); ?>

                                </a>
                            </div>
                        <?php endif; ?>
                        <p class="card-text text-muted flex-grow-1">
                            <?php echo e(Str::limit($product->description, 100)); ?>

                        </p>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="price-tag">
                                    R$ <?php echo e(number_format($product->price, 2, ',', '.')); ?>

                                </span>
                                <span class="badge bg-<?php echo e($product->stock > 0 ? 'success' : 'danger'); ?>">
                                    <i class="fas fa-box me-1"></i>
                                    <?php echo e($product->stock); ?> em estoque
                                </span>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if($product->stock > 0): ?>
                                    <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary w-100">
                                            <i class="fas fa-cart-plus me-2"></i>
                                            Adicionar ao Carrinho
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn btn-secondary w-100" disabled>
                                        <i class="fas fa-times-circle me-2"></i>
                                        Indisponível
                                    </button>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" 
                                   class="btn btn-outline-primary w-100">
                                    <i class="fas fa-sign-in-alt me-2"></i>
                                    Faça login para comprar
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Nenhum produto disponível no momento.
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Paginação -->
    <?php if($products->hasPages()): ?>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($products->links()); ?>

        </div>
    <?php endif; ?>
</div>

<style>
    .category-icon {
        width: 20px;
        height: 20px;
        object-fit: cover;
        border-radius: 3px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\laravel\resources\views/products/vitrine.blade.php ENDPATH**/ ?>